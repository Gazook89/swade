import { getCanvas } from "../util.js";
export default class SwadeCombatant extends Combatant {
    get suitValue() {
        return this.getFlag('swade', 'suitValue');
    }
    async setCardValue(cardValue) {
        return this.setFlag('swade', 'cardValue', cardValue);
    }
    get cardValue() {
        return this.getFlag('swade', 'cardValue');
    }
    async setSuitValue(suitValue) {
        return this.setFlag('swade', 'suitValue', suitValue);
    }
    get cardString() {
        return this.getFlag('swade', 'cardString');
    }
    async setCardString(cardString) {
        return this.setFlag('swade', 'cardString', cardString);
    }
    get hasJoker() {
        return this.getFlag('swade', 'hasJoker');
    }
    async setJoker(joker) {
        return this.setFlag('swade', 'hasJoker', joker);
    }
    get groupId() {
        return this.getFlag('swade', 'groupId');
    }
    async setGroupId(groupId) {
        return this.setFlag('swade', 'groupId', groupId);
    }
    async unsetGroupId() {
        return this.unsetFlag('swade', 'groupId');
    }
    get isGroupLeader() {
        return this.getFlag('swade', 'isGroupLeader');
    }
    async setIsGroupLeader(groupLeader) {
        return this.setFlag('swade', 'isGroupLeader', groupLeader);
    }
    async unsetIsGroupLeader() {
        return this.unsetFlag('swade', 'isGroupLeader');
    }
    get roundHeld() {
        return this.getFlag('swade', 'roundHeld');
    }
    async setRoundHeld(roundHeld) {
        return this.setFlag('swade', 'roundHeld', roundHeld);
    }
    get turnLost() {
        return this.getFlag('swade', 'turnLost');
    }
    async setTurnLost(turnLost) {
        return this.setFlag('swade', 'turnLost', turnLost);
    }
    async _preCreate(data, options, user) {
        await super._preCreate(data, options, user);
        const combatants = game?.combat?.combatants.size;
        const tokenIndex = getCanvas()
            .tokens?.controlled.map((t) => t.id)
            .indexOf(data.tokenId) ?? 0;
        const sortValue = tokenIndex + combatants;
        this.data.update({
            flags: {
                swade: {
                    cardValue: sortValue,
                    suitValue: sortValue,
                },
            },
        });
    }
}
