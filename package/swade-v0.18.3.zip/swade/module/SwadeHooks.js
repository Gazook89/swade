import Bennies from "./bennies.js";
import * as chat from "./chat.js";
import { formatRoll } from "./chat.js";
import { SWADE } from "./config.js";
import DiceSettings from "./DiceSettings.js";
import SwadeItem from "./entities/SwadeItem.js";
import SwadeTemplate from "./entities/SwadeTemplate.js";
import { TemplatePreset } from "./enums/TemplatePresetEnum.js";
import { SwadeSetup } from "./setup/setupHandler.js";
import SwadeVehicleSheet from "./sheets/SwadeVehicleSheet.js";
import { createActionCardTable } from "./util.js";
export default class SwadeHooks {
    static onSetup() {
        // Do anything after initialization but before ready
        // Localize CONFIG objects once up-front
        const toLocalize = [];
        for (const o of toLocalize) {
            SWADE[o] = Object.entries(SWADE[o]).reduce((obj, e) => {
                obj[e[0]] = game.i18n.localize(e[1]);
                return obj;
            }, {});
        }
    }
    static async onReady() {
        const packChoices = {};
        game.packs
            .filter((p) => p.entity === 'JournalEntry')
            .forEach((p) => {
            packChoices[p.collection] = `${p.metadata.label} (${p.metadata.package})`;
        });
        game.settings.register('swade', 'cardDeck', {
            name: 'Card Deck to use for Initiative',
            scope: 'world',
            type: String,
            config: true,
            default: SWADE.init.defaultCardCompendium,
            choices: packChoices,
            onChange: async (choice) => {
                console.log(`Repopulating action cards Table with cards from deck ${choice}`);
                await createActionCardTable(true, choice);
                ui.notifications.info('Table re-population complete');
            },
        });
        await SwadeSetup.setup();
        SWADE.diceConfig.flags = {
            dsnShowBennyAnimation: {
                type: Boolean,
                default: true,
                label: game.i18n.localize('SWADE.ShowBennyAnimation'),
                hint: game.i18n.localize('SWADE.ShowBennyAnimationDesc'),
            },
            dsnWildDie: {
                type: String,
                default: 'none',
                label: game.i18n.localize('SWADE.WildDiePreset'),
                hint: game.i18n.localize('SWADE.WildDiePresetDesc'),
            },
            dsnCustomWildDieColors: {
                type: Object,
                default: {
                    labelColor: '#000000',
                    diceColor: game.user['color'],
                    outlineColor: game.user['color'],
                    edgeColor: game.user['color'],
                },
            },
            dsnCustomWildDieOptions: {
                type: Object,
                default: {
                    font: 'auto',
                    material: 'auto',
                    texture: 'none',
                },
            },
        };
    }
    static onPreCreateItem(createData, options, userId) {
        //Set default image if no image already exists
        if (!createData.img) {
            createData.img = `systems/swade/assets/icons/${createData.type}.svg`;
        }
    }
    static onPreCreateScene(createData, options, userId) {
        if (!createData.gridType) {
            createData.gridType = CONST.GRID_TYPES.GRIDLESS;
        }
    }
    static onPreCreateOwnedItem(actor, createData, options, userId) {
        //Set default image if no image already exists
        if (!createData.img) {
            createData.img = `systems/swade/assets/icons/${createData.type}.svg`;
        }
        if (createData.type === 'skill' && options.renderSheet !== null) {
            options.renderSheet = true;
        }
        if (createData.type === 'ability' && createData.data.subtype === 'race') {
            return false;
        }
        if (actor.data.type === 'npc' &&
            getProperty(createData, 'data.equippable')) {
            createData.data.equipped = true;
        }
    }
    static async onCreateActor(actor, options, userId) {
        // Return early if we are NOT a GM OR we are not the player that triggered the update AND that player IS a GM
        const user = game.users.get(userId);
        if (!game.user.isGM || (game.userId !== userId && user.isGM)) {
            return;
        }
        // Return early if the actor is not a player character
        if (actor.data.type !== 'character') {
            return;
        }
        //return early if the actor already has skills
        if (actor.itemTypes['skill'].length > 0) {
            return;
        }
        //Get list of core skills from settings
        const coreSkills = game.settings.get('swade', 'coreSkills')
            .split(',')
            .map((s) => s.trim());
        //Get and map the existing skills on the actor to an array of names
        const existingSkills = actor.itemTypes['skill'].map((i) => i.name);
        //Filter the expected
        const skillsToAdd = coreSkills.filter((s) => !existingSkills.includes(s));
        //Set compendium source
        const pack = game.settings.get('swade', 'coreSkillsCompendium');
        const skillIndex = (await game.packs.get(pack).getContent());
        // extract skill data
        const skills = skillIndex
            .filter((i) => skillsToAdd.includes(i.data.name))
            .map((i) => i.data);
        await actor.createOwnedItem(skills, { renderSheet: null });
        // Create core skills not in compendium (for custom skill names entered by the user)
        for (const skillName of coreSkills) {
            if (typeof skillIndex.find((skillItem) => skillName === skillItem.data.name) === 'undefined') {
                actor.createOwnedItem({
                    type: 'skill',
                    name: skillName,
                    data: {
                        description: '',
                        notes: '',
                        additionalStats: {},
                        attribute: '',
                        die: {
                            sides: 4,
                            modifier: null,
                        },
                        'wild-die': {
                            sides: 6,
                        },
                    },
                }, { renderSheet: null });
            }
        }
        //Set skills as core skills
        for (const item of actor.items) {
            if (item.type === 'skill' && coreSkills.includes(item.name)) {
                await item.update({ 'data.isCoreSkill': true });
            }
        }
        // Create an Untrained skill that's not a core skill
        actor.createOwnedItem({
            type: 'skill',
            name: 'Untrained',
            data: {
                description: '',
                notes: '',
                additionalStats: {},
                attribute: '',
                die: {
                    sides: 4,
                    modifier: -2,
                },
                'wild-die': {
                    sides: 6,
                },
                isCoreSkill: false,
            },
        }, { renderSheet: null });
    }
    static onRenderActorDirectory(app, html, options) {
        // Mark all Wildcards in the Actors sidebars with an icon
        const found = html.find('.entity-name');
        let wildcards = app.entities.filter((a) => a.isWildcard && a.hasPlayerOwner);
        //if the player is not a GM, then don't mark the NPC wildcards
        if (!game.settings.get('swade', 'hideNPCWildcards') || game.user.isGM) {
            const npcWildcards = app.entities.filter((a) => a.isWildcard && !a.hasPlayerOwner);
            wildcards = wildcards.concat(npcWildcards);
        }
        for (let i = 0; i < found.length; i++) {
            const element = found[i];
            const enitityId = element.parentElement.dataset.entityId;
            const wildcard = wildcards.find((a) => a._id === enitityId);
            if (wildcard) {
                element.innerHTML = `
					<a><img src="${SWADE.wildCardIcons.regular}" class="wildcard-icon">${wildcard.data.name}</a>
					`;
            }
        }
    }
    static async onRenderCompendium(app, html, data) {
        //Mark Wildcards in the compendium
        if (app.entity === 'Actor') {
            const content = await app.getContent();
            const wildcards = content.filter((entity) => entity.isWildcard);
            const ids = wildcards.map((e) => e._id);
            const found = html.find('.directory-item');
            found.each((i, el) => {
                const entryId = el.dataset.entryId;
                if (ids.includes(entryId)) {
                    const entityName = el.children[1];
                    entityName.children[0].insertAdjacentHTML('afterbegin', `<img src="${SWADE.wildCardIcons.compendium}" class="wildcard-icon">`);
                }
            });
            return false;
        }
    }
    static onPreUpdateActor(actor, updateData, options, userId) {
        //wildcards will be linked, extras unlinked
        if (updateData.data &&
            typeof updateData.data.wildcard !== 'undefined' &&
            game.settings.get('swade', 'autoLinkWildcards')) {
            updateData.token = { actorLink: updateData.data.wildcard };
        }
    }
    static onUpdateActor(actor, updateData, options, userId) {
        var _a;
        if (actor.data.type === 'npc') {
            ui.actors.render();
        }
        // Update the player list to display new bennies values
        if ((_a = updateData === null || updateData === void 0 ? void 0 : updateData.data) === null || _a === void 0 ? void 0 : _a.bennies) {
            ui['players'].render(true);
        }
    }
    static onRenderCombatTracker(app, html, data) {
        const currentCombat = data.combats[data.currentIndex - 1] || data.combat;
        html.find('.combatant').each((i, el) => {
            const combId = el.getAttribute('data-combatant-id');
            const combatant = currentCombat.combatants.find((c) => c._id == combId);
            const initdiv = el.getElementsByClassName('token-initiative');
            if (combatant.initiative && combatant.initiative !== 0) {
                const cardString = getProperty(combatant, 'flags.swade.cardString');
                initdiv[0].innerHTML = `<span class="initiative">${cardString}</span>`;
            }
            else if (!game.user.isGM) {
                initdiv[0].innerHTML = '';
            }
        });
    }
    static onUpdateCombatant(combat, combatant, updateData, options, userId) {
        // Return early if we are NOT a GM OR we are not the player that triggered the update AND that player IS a GM
        const user = game.users.get(userId);
        if (!game.user.isGM || (game.userId !== userId && user.isGM)) {
            return;
        }
        if (!getProperty(updateData, 'flags.swade') ||
            combatant.actor.data.type !== 'character')
            return;
        if (getProperty(combatant, 'flags.swade.hasJoker') &&
            game.settings.get('swade', 'jokersWild')) {
            renderTemplate(SWADE.bennies.templates.joker, {
                speaker: game.user,
            })
                .then((template) => {
                const createData = { user: game.user, content: template };
                ChatMessage.create(createData);
            })
                .then(() => {
                const combatants = combat.combatants.filter((c) => c.actor.data.type === 'character');
                for (const combatant of combatants) {
                    const actor = combatant.actor;
                    actor.getBenny();
                }
            });
        }
    }
    static onDeleteCombat(combat, options, userId) {
        if (!game.user.isGM || !game.users.get(userId).isGM) {
            return;
        }
        const jokerDrawn = combat.combatants.some((v) => getProperty(v, 'flags.swade.hasJoker'));
        //return early if no Jokers have been drawn
        if (!jokerDrawn)
            return;
        //reset the deck when combat is ended
        game.tables
            .getName(SWADE.init.cardTable)
            .reset()
            .then(() => {
            ui.notifications.info('Card Deck automatically reset');
        });
    }
    static async onRenderChatMessage(message, html, data) {
        if (message.isRoll && message.isContentVisible) {
            await formatRoll(message, html, data);
        }
        chat.hideChatActionButtons(message, html, data);
    }
    static onGetChatLogEntryContext(html, options) {
        const canApply = (li) => {
            const message = game.messages.get(li.data('messageId'));
            const actor = ChatMessage.getSpeakerActor(message.data['speaker']);
            const isRightMessageType = (message === null || message === void 0 ? void 0 : message.isRoll) &&
                (message === null || message === void 0 ? void 0 : message.isContentVisible) &&
                !message.getFlag('core', 'RollTable');
            return isRightMessageType && !!actor && (game.user.isGM || actor.owner);
        };
        options.push({
            name: game.i18n.localize('SWADE.RerollWithBenny'),
            icon: '<i class="fas fa-dice"></i>',
            condition: canApply,
            callback: (li) => chat.rerollFromChat(li, true),
        }, {
            name: game.i18n.localize('SWADE.FreeReroll'),
            icon: '<i class="fas fa-dice"></i>',
            condition: canApply,
            callback: (li) => chat.rerollFromChat(li, false),
        });
    }
    static onGetCombatTrackerEntryContext(html, options) {
        const index = options.findIndex((v) => v.name === 'COMBAT.CombatantReroll');
        if (index !== -1) {
            options[index].name = 'SWADE.Redraw';
            options[index].icon = '<i class="fas fa-sync-alt"></i>';
        }
    }
    static async onRenderPlayerList(list, html, options) {
        html.find('.player').each((id, player) => {
            Bennies.append(player, options);
        });
    }
    static onRenderChatLog(app, html, data) {
        chat.chatListeners(html);
    }
    static onGetUserContextOptions(html, context) {
        const players = html.find('#players');
        if (!players)
            return;
        context.push({
            name: game.i18n.localize('SWADE.BenniesGive'),
            icon: '<i class="fas fa-plus"></i>',
            condition: (li) => game.user.isGM && game.users.get(li[0].dataset.userId).isGM,
            callback: (li) => {
                const selectedUser = game.users.get(li[0].dataset.userId);
                selectedUser
                    .setFlag('swade', 'bennies', selectedUser.getFlag('swade', 'bennies') + 1)
                    .then(async () => {
                    ui['players'].render(true);
                    if (game.settings.get('swade', 'notifyBennies')) {
                        //In case one GM gives another GM a benny a different message should be displayed
                        const givenEvent = selectedUser !== game.user;
                        chat.createGmBennyAddMessage(selectedUser, givenEvent);
                    }
                });
            },
        }, {
            name: game.i18n.localize('SWADE.BenniesRefresh'),
            icon: '<i class="fas fa-sync"></i>',
            condition: (li) => game.user.isGM,
            callback: (li) => {
                const user = game.users.get(li[0].dataset.userId);
                Bennies.refresh(user);
            },
        }, {
            name: game.i18n.localize('SWADE.AllBenniesRefresh'),
            icon: '<i class="fas fa-sync"></i>',
            condition: (li) => game.user.isGM,
            callback: (li) => {
                Bennies.refreshAll();
            },
        });
    }
    static onGetSceneControlButtons(sceneControlButtons) {
        const measure = sceneControlButtons.find((a) => a.name === 'measure');
        let template = null;
        const newButtons = [
            {
                name: 'swcone',
                title: 'SWADE.Cone',
                icon: 'cone far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    if (template)
                        template.destroy();
                    template = SwadeTemplate.fromPreset(TemplatePreset.CONE);
                    if (template)
                        template.drawPreview();
                },
            },
            {
                name: 'sbt',
                title: 'SWADE.SBT',
                icon: 'sbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    if (template)
                        template.destroy();
                    template = SwadeTemplate.fromPreset(TemplatePreset.SBT);
                    if (template)
                        template.drawPreview();
                },
            },
            {
                name: 'mbt',
                title: 'SWADE.MBT',
                icon: 'mbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    if (template)
                        template.destroy();
                    template = SwadeTemplate.fromPreset(TemplatePreset.MBT);
                    if (template)
                        template.drawPreview();
                },
            },
            {
                name: 'lbt',
                title: 'SWADE.LBT',
                icon: 'lbt far fa-circle',
                visible: true,
                button: true,
                onClick: () => {
                    if (template)
                        template.destroy();
                    template = SwadeTemplate.fromPreset(TemplatePreset.LBT);
                    if (template)
                        template.drawPreview();
                },
            },
        ];
        measure.tools.splice(measure.tools.length - 1, 0, ...newButtons);
    }
    static async onDropActorSheetData(actor, sheet, data) {
        if (data.type === 'Actor' && actor.data.type === 'vehicle') {
            const vehicleSheet = sheet;
            const activeTab = getProperty(vehicleSheet, '_tabs')[0].active;
            if (activeTab === 'summary') {
                vehicleSheet.setDriver(data.id);
            }
            return false;
        }
        if (data.type === 'Item' && !(sheet instanceof SwadeVehicleSheet)) {
            let item;
            if ('pack' in data) {
                const pack = game.packs.get(data.pack);
                item = (await pack.getEntity(data.id));
            }
            else if ('actorId' in data) {
                item = new SwadeItem(data.data, {});
            }
            else {
                item = game.items.get(data.id);
            }
            const isRightItemTypeAndSubtype = item.data.type === 'ability' && item.data.data.subtype === 'race';
            if (!isRightItemTypeAndSubtype)
                return false;
            //set name
            await actor.update({ 'data.details.species.name': item.name });
            //process embedded entities
            const map = new Map(item.getFlag('swade', 'embeddedAbilities') || []);
            const creationData = [];
            for (const entry of map.values()) {
                //if the item isn't a skill, then push it to the new items
                if (entry.type !== 'skill') {
                    creationData.push(entry);
                }
                else {
                    //else, check if there's already a skill like that that exists
                    const skill = actor.items.find((i) => i.type === 'skill' && i.name === entry.name);
                    if (skill) {
                        //if the skill exists, set it to the value of the skill from the item
                        const skillDie = getProperty(entry, 'data.die');
                        await actor.updateOwnedItem({
                            _id: skill.id,
                            data: { die: skillDie },
                        });
                    }
                    else {
                        //else, add it to the new items
                        creationData.push(entry);
                    }
                }
            }
            if (creationData.length > 0) {
                await actor.createOwnedItem(creationData, { renderSheet: null });
            }
            //copy active effects
            const effects = item.effects.map((ae) => ae.data);
            if (!!effects && effects.length > 0) {
                await actor.createEmbeddedEntity('ActiveEffect', effects);
            }
        }
    }
    static async onRenderCombatantConfig(app, html, options) {
        // resize the element so it'll fit the new stuff
        html.css({ height: 'auto' });
        //remove the old initiative input
        html.find('input[name="initiative"]').parents('div.form-group').remove();
        //grab cards and sort them
        const cardPack = game.packs.get(game.settings.get('swade', 'cardDeck'));
        const cards = (await cardPack.getContent()).sort((a, b) => {
            const cardA = a.getFlag('swade', 'cardValue');
            const cardB = b.getFlag('swade', 'cardValue');
            const card = cardA - cardB;
            if (card !== 0)
                return card;
            const suitA = a.getFlag('swade', 'suitValue');
            const suitB = b.getFlag('swade', 'suitValue');
            const suit = suitA - suitB;
            return suit;
        });
        //prep list of cards for selection
        const cardTable = game.tables.getName(SWADE.init.cardTable);
        const cardList = [];
        for (const card of cards) {
            const cardValue = card.getFlag('swade', 'cardValue');
            const suitValue = card.getFlag('swade', 'suitValue');
            const color = suitValue === 2 || suitValue === 3 ? 'color: red;' : 'color: black;';
            const isDealt = options.object.flags.swade &&
                options.object.flags.swade.cardValue === cardValue &&
                options.object.flags.swade.suitValue === suitValue;
            const isAvailable = cardTable.results.find((r) => r.text === card.name)
                .drawn
                ? 'text-decoration: line-through;'
                : '';
            cardList.push({
                cardValue,
                suitValue,
                isDealt,
                color,
                isAvailable,
                name: card.name,
                cardString: getProperty(card, 'data.content'),
                isJoker: card.getFlag('swade', 'isJoker'),
            });
        }
        const numberOfJokers = cards.filter((c) => c.getFlag('swade', 'isJoker'))
            .length;
        //render and inject new HTML
        const path = 'systems/swade/templates/combatant-config-cardlist.html';
        $(await renderTemplate(path, { cardList, numberOfJokers })).insertBefore(`#${options.options.id} footer`);
        //Attach click event to button which will call the combatant update as we can't easily modify the submit function of the FormApplication
        html.find('footer button').on('click', (ev) => {
            const selectedCard = html.find('input[name=ActionCard]:checked');
            if (selectedCard.length === 0) {
                return;
            }
            const cardValue = selectedCard.data().cardValue;
            const suitValue = selectedCard.data().suitValue;
            const hasJoker = selectedCard.data().isJoker;
            const cardString = selectedCard.val();
            game.combat.updateEmbeddedEntity('Combatant', {
                _id: options.object._id,
                initiative: suitValue + cardValue,
                flags: { swade: { cardValue, suitValue, hasJoker, cardString } },
            });
        });
        return false;
    }
    static onPreUpdateToken(scene, token, updateData, options, userId) {
        const actor = game.actors.get(token.actorId);
        if (!!actor && actor.data.type === 'npc') {
            const items = getProperty(updateData, 'actorData.items') || [];
            for (const item of items) {
                if (getProperty(item, 'data.equippable')) {
                    item.data.equipped = true;
                }
            }
        }
    }
    static onDiceSoNiceInit(dice3d) {
        game.settings.registerMenu('swade', 'dice-config', {
            name: game.i18n.localize('SWADE.DiceConf'),
            label: game.i18n.localize('SWADE.DiceConfLabel'),
            hint: game.i18n.localize('SWADE.DiceConfDesc'),
            icon: 'fas fa-dice',
            type: DiceSettings,
            restricted: false,
        });
    }
    static onDiceSoNiceReady(dice3d) {
        //@ts-ignore
        import('/modules/dice-so-nice/DiceColors.js')
            .then((obj) => {
            SWADE.dsnColorSets = obj.COLORSETS;
            SWADE.dsnTextureList = obj.TEXTURELIST;
        })
            .catch((err) => console.log(err));
        const customWilDieColors = game.user.getFlag('swade', 'dsnCustomWildDieColors') ||
            getProperty(SWADE, 'diceConfig.flags.dsnCustomWildDieColors.default');
        const customWilDieOptions = game.user.getFlag('swade', 'dsnCustomWildDieOptions') ||
            getProperty(SWADE, 'diceConfig.flags.dsnCustomWildDieOptions.default');
        dice3d.addColorset({
            name: 'customWildDie',
            description: 'DICESONICE.ColorCustom',
            category: 'DICESONICE.Colors',
            foreground: customWilDieColors.labelColor,
            background: customWilDieColors.diceColor,
            outline: customWilDieColors.outlineColor,
            edge: customWilDieColors.edgeColor,
            texture: customWilDieOptions.texture,
            material: customWilDieOptions.material,
            font: customWilDieOptions.font,
        }, 'no');
        dice3d.addDicePreset({
            type: 'db',
            labels: [SWADE.bennies.textures.front, SWADE.bennies.textures.back],
            system: 'standard',
            colorset: 'black',
        }, 'd2');
    }
}
