export var ArmorLocation;
(function (ArmorLocation) {
    ArmorLocation["Head"] = "head";
    ArmorLocation["Torso"] = "torso";
    ArmorLocation["Legs"] = "legs";
    ArmorLocation["Arms"] = "arms";
})(ArmorLocation || (ArmorLocation = {}));
