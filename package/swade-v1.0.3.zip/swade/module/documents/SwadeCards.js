export default class SwadeCards extends Cards {
    async dealForInitative(to, number = 1, how = foundry.CONST.CARD_DRAW_MODES.TOP) {
        //validate
        if (this.data.type !== 'deck') {
            throw new Error('You can only deal cards for Initiative from a Deck');
        }
        // Draw from the sorted stack
        const drawn = this._drawCards(number, how);
        // Process the card data
        const toCreate = new Array();
        const toUpdate = new Array();
        const toDelete = new Array();
        for (const card of drawn) {
            const createData = card.toObject();
            if (card.isHome || !createData.origin)
                createData.origin = this.id;
            toCreate.push(createData);
            if (card.isHome)
                toUpdate.push({ _id: card.id, drawn: true });
            else
                toDelete.push(card.id);
        }
        // yeet the data
        await Promise.all([
            to.createEmbeddedDocuments('Card', toCreate, {
                keepId: true,
            }),
            this.deleteEmbeddedDocuments('Card', toDelete),
        ]);
        const updated = await this.updateEmbeddedDocuments('Card', toUpdate);
        return updated;
    }
}
