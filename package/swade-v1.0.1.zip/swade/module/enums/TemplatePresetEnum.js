export var TemplatePreset;
(function (TemplatePreset) {
    TemplatePreset["CONE"] = "swcone";
    TemplatePreset["SBT"] = "sbt";
    TemplatePreset["MBT"] = "mbt";
    TemplatePreset["LBT"] = "lbt";
})(TemplatePreset || (TemplatePreset = {}));
