export var StatusEffectExpiration;
(function (StatusEffectExpiration) {
    StatusEffectExpiration[StatusEffectExpiration["StartOfTurnAuto"] = 0] = "StartOfTurnAuto";
    StatusEffectExpiration[StatusEffectExpiration["StartOfTurnPrompt"] = 1] = "StartOfTurnPrompt";
    StatusEffectExpiration[StatusEffectExpiration["EndOfTurnAuto"] = 2] = "EndOfTurnAuto";
    StatusEffectExpiration[StatusEffectExpiration["EndOfTurnPrompt"] = 3] = "EndOfTurnPrompt";
})(StatusEffectExpiration || (StatusEffectExpiration = {}));
