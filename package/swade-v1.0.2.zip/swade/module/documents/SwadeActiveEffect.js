import { StatusEffectExpiration } from "../enums/StatusEffectExpirationsEnums.js";
import { isFirstOwner } from "../util.js";
export default class SwadeActiveEffect extends ActiveEffect {
    get changes() {
        return this.data.changes;
    }
    get affectsItems() {
        if (this.parent instanceof CONFIG.Actor.documentClass) {
            const affectedItems = new Array();
            this.changes.forEach((c) => affectedItems.push(...this._getAffectedItems(this.parent, c)));
            return affectedItems.length > 0;
        }
        return false;
    }
    /** @override */
    apply(actor, change) {
        const match = change.key.match(SwadeActiveEffect.ITEM_REGEXP);
        if (match) {
            //get the properties from the match
            const key = match[3].trim();
            const value = change.value;
            //get the affected items
            const affectedItems = this._getAffectedItems(actor, change);
            //apply the AE to each item
            for (const item of affectedItems) {
                const overrides = foundry.utils.flattenObject(item.overrides);
                overrides[key] = Number.isNumeric(value) ? Number(value) : value;
                //mock up a new change object with the key and value we extracted from the original key and feed it into the super apply method alongside the item
                const mockChange = { ...change, key, value };
                //@ts-expect-error It normally expects an Actor but since it only targets the data we can re-use it for Items
                super.apply(item, mockChange);
                item.overrides = foundry.utils.expandObject(overrides);
            }
        }
        else {
            return super.apply(actor, change);
        }
    }
    _getAffectedItems(actor, change) {
        const items = new Array();
        const match = change.key.match(SwadeActiveEffect.ITEM_REGEXP);
        if (match) {
            //get the properties from the match
            const type = match[1].trim().toLowerCase();
            const name = match[2].trim();
            //filter the items down, according to type and name/id
            items.push(...actor.items.filter((i) => i.type === type && (i.name === name || i.id === name)));
        }
        return items;
    }
    /**
     * Removes Effects from Items
     * @param parent The parent object
     */
    _removeEffectsFromItems(parent) {
        const affectedItems = new Array();
        this.changes.forEach((c) => affectedItems.push(...this._getAffectedItems(parent, c)));
        for (const item of affectedItems) {
            const overrides = foundry.utils.flattenObject(item.overrides);
            for (const change of this.changes) {
                const match = change.key.match(SwadeActiveEffect.ITEM_REGEXP);
                if (match) {
                    const key = match[3].trim();
                    //delete override
                    delete overrides[key];
                    //restore original data from source
                    const source = getProperty(item.data._source, key);
                    setProperty(item.data, key, source);
                }
            }
            item.overrides = foundry.utils.expandObject(overrides);
            if (item.sheet?.rendered)
                item.sheet.render(true);
        }
    }
    /**
     * This functions checks the effect expiration behavior and either auto-deletes or prompts for deletion
     */
    async removeEffect() {
        const expiration = this.getFlag('swade', 'expiration');
        const startOfTurnAuto = expiration === StatusEffectExpiration.StartOfTurnAuto;
        const startOfTurnPrompt = expiration === StatusEffectExpiration.StartOfTurnPrompt;
        const endOfTurnAuto = expiration === StatusEffectExpiration.EndOfTurnAuto;
        const endOfTurnPrompt = expiration === StatusEffectExpiration.EndOfTurnPrompt;
        const auto = startOfTurnAuto || endOfTurnAuto;
        const prompt = startOfTurnPrompt || endOfTurnPrompt;
        if (auto) {
            await this.delete();
        }
        else if (prompt) {
            this.promptEffectDeletion();
        }
    }
    /**
     * //TODO: trigger prompt based on effect
     * This function creates a dialog for status effect deletion
     */
    promptEffectDeletion() {
        if (isFirstOwner(this.parent)) {
            Dialog.confirm({
                title: game.i18n.format('SWADE.RemoveEffectTitle', {
                    label: this.data.label,
                }),
                content: game.i18n.format('SWADE.RemoveEffectBody', {
                    label: this.data.label,
                    parent: this.parent?.name,
                }),
                defaultYes: false,
                yes: () => {
                    this.delete();
                },
            });
        }
        else {
            game.swade.sockets.removeStatusEffect(this.uuid);
        }
    }
    async _onUpdate(changed, options, userId) {
        await super._onUpdate(changed, options, userId);
        if (this.getFlag('swade', 'loseTurnOnHold')) {
            const combatant = game.combat?.combatants.find((c) => c.actor?.id === this.parent?.id);
            if (combatant?.getFlag('swade', 'roundHeld')) {
                await combatant?.setFlag('swade', 'turnLost', true);
                await combatant?.unsetFlag('swade', 'roundHeld');
            }
        }
    }
    async _preUpdate(changed, options, user) {
        super._preUpdate(changed, options, user);
        //return early if the parent isn't an actor or we're not actually affecting items
        if (this.affectsItems &&
            this.parent instanceof CONFIG.Actor.documentClass) {
            this._removeEffectsFromItems(this.parent);
        }
    }
    async _preDelete(options, user) {
        super._preDelete(options, user);
        const parent = this.parent;
        //remove the effects from the item
        if (this.affectsItems && parent instanceof CONFIG.Actor.documentClass) {
            this._removeEffectsFromItems(parent);
        }
    }
    async _preCreate(data, options, user) {
        super._preCreate(data, options, user);
        const label = game.i18n.localize(this.data.label);
        await this.data.update({ label: label });
        // If there's no duration value and there's a combat, at least set the combat ID which then sets a startRound and startTurn, too.
        if (!data.duration?.combat && game.combat) {
            await this.data.update({ 'duration.combat': game.combat.id });
        }
        if (this.getFlag('swade', 'loseTurnOnHold')) {
            const combatant = game.combat?.combatants.find((c) => c.actor?.id === this.parent?.id);
            if (combatant?.getFlag('swade', 'roundHeld')) {
                await combatant?.setFlag('swade', 'turnLost', true);
                await combatant?.unsetFlag('swade', 'roundHeld');
            }
        }
    }
}
SwadeActiveEffect.ITEM_REGEXP = /@([a-zA-Z0-9]+){([^.]+)}\[([a-zA-Z0-9.]+)\]/;
