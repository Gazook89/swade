export var ArmorLocation;
(function (ArmorLocation) {
    ArmorLocation["HEAD"] = "head";
    ArmorLocation["TORSO"] = "torso";
    ArmorLocation["LEGS"] = "legs";
    ArmorLocation["ARMS"] = "arms";
})(ArmorLocation || (ArmorLocation = {}));
