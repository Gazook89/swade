import * as util from "./util.js";
export default class SwadeSocketHandler {
    constructor() {
        this.identifier = 'system.swade';
        //register socket listeners
        this.registerSocketListeners();
    }
    /**
     * registers all the socket listeners
     */
    registerSocketListeners() {
        game.socket?.on(this.identifier, (data) => {
            switch (data.type) {
                case 'deleteConvictionMessage':
                    this._onDeleteConvictionMessage(data);
                    break;
                case 'newRound':
                    this._onNewRound(data);
                    break;
                case 'removeStatusEffect':
                    this._onRemoveStatusEffect(data);
                    break;
                default:
                    this._onUnknownSocket(data.type);
                    break;
            }
        });
    }
    deleteConvictionMessage(messageId) {
        game.socket?.emit(this.identifier, {
            type: 'deleteConvictionMessage',
            messageId,
            userId: game.userId,
        });
    }
    removeStatusEffect(uuid) {
        game.socket?.emit(this.identifier, {
            type: 'removeStatusEffect',
            effectUUID: uuid,
        });
    }
    newRound(combatId) {
        game.socket?.emit(this.identifier, {
            type: 'newRound',
            combatId: combatId,
        });
    }
    async _onRemoveStatusEffect(data) {
        const effect = (await fromUuid(data.effectUUID));
        if (util.isFirstOwner(effect.parent)) {
            effect.promptEffectDeletion();
        }
    }
    _onDeleteConvictionMessage(data) {
        const message = game.messages?.get(data.messageId);
        //only delete the message if the user is a GM and the event emitter is one of the recipients
        if (game.user.isGM && message?.data.whisper.includes(data.userId)) {
            message?.delete();
        }
    }
    async _onNewRound(data) {
        if (util.isFirstGM())
            return;
        //advance round
        game.combats.get(data.combatId).nextRound();
    }
    _onUnknownSocket(type) {
        console.warn(`The socket event ${type} is not supported`);
    }
}
