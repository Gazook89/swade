export default class Benny extends DiceTerm {
    constructor(termData) {
        termData.faces = 2;
        super(termData);
    }
    /** @override */
    get isDeterministic() {
        return true;
    }
    /** @override */
    getResultLabel(_result) {
        return 'b';
    }
}
/** @override */
Benny.DENOMINATION = 'b';
